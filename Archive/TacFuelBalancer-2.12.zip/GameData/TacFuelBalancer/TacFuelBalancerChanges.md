Tac Fuel Balancer
=================



2.12
----
07-Dec-2016 Built against KSP V1.2.2
* Rebuilt for new version of KSP



2.11
----
03-Nov-2016 Built against KSP V1.2.1
* Rebuilt for new version of KSP



2.10
----
24-Oct-2016 Built against KSP V1.2
* Fix for Contract Configurator/Toolbar bug



2.9
---
15-Oct-2016 Built against KSP V1.2
* Rebuilt for KSP 1.2



2.8
---
22-June-2016 Built against KSP V1.1.3

* Resource buttons act like tabs by default
* Help and settings buttons toggle visibility
* ToolTips



2.7
---
14-June-2016 Built against KSP V1.1.2

* Stock toolbar "Launcher" button
* New icon set
* F2 support
* Reset button
* Support for mods that change tank contents



2.6
---
10-May-2016 Built against KSP V1.1.2

* Added changes by AdamMil



2.5.3
-----
3-May-2016 Built against KSP V1.1.1

* Rebuilt for KSP V1.1.1



2.5.2
-----
29-April-2016 Built against KSP V1.1.0

* Rebuilt for KSP V1.1.0



Release v2.5.1

- Updated for KSP 1.0.2.

Release v2.4.1

- See the release announcement.

Release v2.4

- See the release announcement.

Release v2.3

- See http://forum.kerbalspaceprogram.com/threads/25823?p=863104&viewfull=1#post863104

Release v2.2

- See http://forum.kerbalspaceprogram.com/showthread.php/25823?p=858321&viewfull=1#post858321

Release v2.1

- See http://forum.kerbalspaceprogram.com/threads/25823-0-21-1-TAC-Fuel-Balancer-25Jul?p=789484&viewfull=1#post789484

Release v2.0

- All windows are now resizable and feature scroll bars.

- Can now edit the fuel amount before launch -- for launching empty tanks or reducing the amount of solid fuel in boosters. Can also fill a Kethane tank with Kethane on the launch pad for testing purposes.

- Can dump fuel -- this can be disabled through settings if you do not want it or are afraid of accidentally clicking it.

- The Lock feature is now linked with the flow state on the part (in the part's right click menu).

- Disabled if out of power or the vessel is not "controllable". (Sorry, no integration with RemoteTech. I will have to look at that later.)

- No parts are needed! There is now an icon at the screen edge (default to top right) that is used for showing and hiding the main window. The icon can be re-positioned to anywhere along the screen edge.

Release V1.1.1

- the previous upload was missing the Readme and License files. That is the only difference.

Release V1.1

- created a new 3D model

Release V1.0

- fully functional, and tested with 0.19

- uses the same model as the Double-C Accelerometer -- new model coming soon!